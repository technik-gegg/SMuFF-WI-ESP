# SCRIPT TO GZIP CRITICAL FILES FOR ACCELERATED WEBSERVING
# see also https://community.platformio.org/t/question-esp32-compress-files-in-data-to-gzip-before-upload-possible-to-spiffs/6274/10
#

Import( 'env' )

import os.path, pathlib
import gzip
import shutil
import glob

# HELPER TO GZIP A FILE
def gzip_file( src_path, dst_path ):
    with open( src_path, 'rb' ) as src, gzip.open( dst_path, 'wb' ) as dst:
        for chunk in iter( lambda: src.read(4096), b"" ):
            dst.write( chunk )

# GZIP DEFINED FILES FROM 'data_src' DIR to 'data' DIR
def gzip_webfiles( source, target, env ):
    
    # FILETYPES / SUFFIXES WHICH NEED TO BE GZIPPED
    filetypes_to_gzip = [ '.css', '.html', '.htm', '.png', '.js','.min.js', '.jpg', '.jpeg' ]

    print( '\nGZIP: Started...' )
    GZIP_DIR_NAME = env.get( 'PROJECT_DATA_DIR' )

    data_dir_path = GZIP_DIR_NAME + '_src'
    gzip_dir_path = GZIP_DIR_NAME

    print('>>>', gzip_dir_path)
    print('>>>', data_dir_path)

    # CHECK DATA DIR
    if not os.path.exists( data_dir_path ):
        print( 'GZIP: Source data folder "{}" not found. Please create it first and copy the files into it.'.format(data_dir_path))
        env.Exit(-1)
    
    # CHECK GZIP DIR
    if not os.path.exists( gzip_dir_path ):
        print('GZIP: Creating destination folder "{}"'.format(gzip_dir_path))
        try:
            os.mkdir(gzip_dir_path)
        except Exception as e:
            print( 'GZIP: Failed to create destination folder "{}"'.format(gzip_dir_path))
            env.Exit(-1)

    # DETERMINE FILES TO COMPRESS
    files_to_gzip = []
    files_to_gzip_folder = []
    dest_path = ''
    for file in glob.glob(data_dir_path + os.sep + '**/*', recursive=True):
        if not os.path.isdir(file):
            # print('{} => {}'.format(file, ''.join(pathlib.Path(file).suffixes)))
            if ''.join(pathlib.Path(file).suffixes) in filetypes_to_gzip:
                print('Found: {} => {}'.format(dest_path, file))
                files_to_gzip_folder.append(dest_path)
                files_to_gzip.append(file)
        else:
            dest_path = gzip_dir_path + file[len(data_dir_path):]
            try:
                if not os.path.exists(dest_path):
                    print('Sub: {}'.format(dest_path))
                    os.mkdir(dest_path)
            except Exception as e:
                print( 'GZIP: Failed to create destination folder "{}"'.format(dest_path))

    env.Exit(-1)

    # COMPRESS AND MOVE FILES
    was_error = False
    try:
        i = 0
        for source_file_path in files_to_gzip:
            print( 'GZIP: Zipping... {}'.format(source_file_path))
            base_file_path = source_file_path
            target_file_path = os.path.join( gzip_dir_path, files_to_gzip_folder[i] + '.gz' )
            # CHECK IF FILE ALREADY EXISTS
            if os.path.exists( target_file_path ):
                print( 'GZIP: Deleting... {}'.format(target_file_path) )
                os.remove( target_file_path )

            # print( 'GZIP: GZIPPING FILE...\n' + source_file_path + ' TO...\n' + target_file_path + "\n\n" )
            print( 'GZIP: Zipped... {}'.format(target_file_path) )
            gzip_file( source_file_path, target_file_path )
            i += 1
    except IOError as e:
        was_error = True
        print( 'GZIP: Failed to ZIP file "{}"'.format(source_file_path))
    if was_error:
        env.Exit(-1)
    else:
        print( 'GZIP: Done.\n' )

# IMPORTANT, this needs to be added to call the routine
env.AddPreAction( '$BUILD_DIR/littlefs.bin', gzip_webfiles )